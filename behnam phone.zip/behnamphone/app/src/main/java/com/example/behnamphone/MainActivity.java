package com.example.behnamphone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.concurrent.ConcurrentHashMap;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
     setContentView(R.layout.activity_main);
     final Button profile =findViewById(R.id.pro);
     final Button dai = findViewById(R.id.dial);
     dai.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             Intent y = new Intent(MainActivity.this , DailActivity.class );
             startActivity(y);

         }
     });
     profile.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             Intent x = new Intent(MainActivity.this , Edit.class);
             startActivity(x);

         }


     });






    }

}
